import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JLabel;

public class Main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 797, 541);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("STUDENT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudentSubMain subMainFrame = new StudentSubMain();
				subMainFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(27, 285, 201, 33);
		contentPane.add(btnNewButton);
		
		JButton btnSection = new JButton("SECTION");
		btnSection.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SectionSubMain SectionsubMainFrame = new SectionSubMain();
				SectionsubMainFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnSection.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSection.setBounds(535, 285, 201, 33);
		contentPane.add(btnSection);
		
		JButton btnStudent_Takes = new JButton("STUDENT_TAKES");
		btnStudent_Takes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_TakesSubMain Student_TakessubMainFrame = new Student_TakesSubMain();
				Student_TakessubMainFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnStudent_Takes.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnStudent_Takes.setBounds(238, 285, 276, 33);
		contentPane.add(btnStudent_Takes);
		
		JLabel lblNewLabel = new JLabel("WELCOME TO THE COST ESTIMATOR APPLICATION");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(40, 20, 710, 77);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("CHOOSE A TABLE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(276, 177, 212, 33);
		contentPane.add(lblNewLabel_1);

	}
}
