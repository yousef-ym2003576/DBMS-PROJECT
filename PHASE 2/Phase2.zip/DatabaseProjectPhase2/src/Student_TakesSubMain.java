import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JLabel;

public class Student_TakesSubMain extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_TakesSubMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 797, 541);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("DISPLAY DATA");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DisplayStudent_TakesTable DisplayStudent_TakesTableFrame = new DisplayStudent_TakesTable();
				DisplayStudent_TakesTableFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(163, 285, 209, 33);
		contentPane.add(btnNewButton);
		
		
		JButton btnMetaDataStatistics = new JButton("DISPLAY METADATA & STATISTICS");
		btnMetaDataStatistics.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DisplayStudent_TakesMetaDataAndStatistics DisplayStudent_TakesMetaDataFrame = new DisplayStudent_TakesMetaDataAndStatistics();
				DisplayStudent_TakesMetaDataFrame.setVisible(true);
				setVisible(false);
			}
		});
		btnMetaDataStatistics.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnMetaDataStatistics.setBounds(195, 355, 403, 33);
		contentPane.add(btnMetaDataStatistics);
		
		JLabel lblNewLabel_1 = new JLabel("CHOOSE A SERVICE");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(278, 202, 234, 33);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Go Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.main(null);
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton_1.setBounds(0, 0, 84, 33);
		contentPane.add(btnNewButton_1);
		
		JButton btnCostEstimator = new JButton("COST ESTIMATOR");
		btnCostEstimator.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CostEstimatorStudent_Takes CostEstimatorStudent_TakesFrame = new CostEstimatorStudent_Takes();
				CostEstimatorStudent_TakesFrame.setVisible(true);
				setVisible(false);
			}
		});	
		btnCostEstimator.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCostEstimator.setBounds(409, 285, 234, 33);
		contentPane.add(btnCostEstimator);
		

	}
}
