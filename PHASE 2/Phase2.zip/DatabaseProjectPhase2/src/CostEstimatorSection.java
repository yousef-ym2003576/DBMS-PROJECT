import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;

public class CostEstimatorSection extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnDisplayColumn;
	private JButton btnDisplayIndex;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CostEstimatorSection frame = new CostEstimatorSection();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CostEstimatorSection() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 342, 966, 211);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		btnNewButton = new JButton("USING A PRIMARY KEY AND EQUALITY OPERATOR ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "DELETE FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql);
					String sql2 = "EXPLAIN PLAN FOR \r\n"
							+ "SELECT * FROM SECTION WHERE SecId = 14281";
					ut.rs = ut.stmt.executeQuery(sql2);
					String sql3 = "SELECT PLAN_ID, OPERATION, OPTIONS, OBJECT_NAME, OBJECT_TYPE, COST, CARDINALITY, BYTES, TIME\r\n"
							+ "FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql3);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(10, 102, 457, 41);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Go Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SectionSubMain SectionsubmainFrame = new SectionSubMain();
				SectionsubmainFrame.setVisible(true);
				setVisible(false);
			}
			
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_1.setBounds(0, 0, 116, 31);
		contentPane.add(btnNewButton_1);
		
		btnDisplayColumn = new JButton("USING A PRIMARY KEY WITH RANGE OPERATOR");
		btnDisplayColumn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "DELETE FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql);
					String sql2 = "EXPLAIN PLAN FOR \r\n"
							+ "SELECT * FROM SECTION WHERE SecId > 11900";
					ut.rs = ut.stmt.executeQuery(sql2);
					String sql3 = "SELECT PLAN_ID, OPERATION, OPTIONS, OBJECT_NAME, OBJECT_TYPE, COST, CARDINALITY, BYTES, TIME\r\n"
							+ "FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql3);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			}
		);
		btnDisplayColumn.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDisplayColumn.setBounds(10, 162, 457, 41);
		contentPane.add(btnDisplayColumn);
		
		btnDisplayIndex = new JButton("USING A NON-PRIMARY KEY AND EQUALITY OPERATOR");
		btnDisplayIndex.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "DELETE FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql);
					String sql2 = "EXPLAIN PLAN FOR\r\n"
							+ "SELECT * FROM SECTION WHERE ROOMNO = 'E112'";
					ut.rs = ut.stmt.executeQuery(sql2);
					String sql3 = "SELECT PLAN_ID, OPERATION, OPTIONS, OBJECT_NAME, OBJECT_TYPE, COST, CARDINALITY, BYTES, TIME\r\n"
							+ "FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql3);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnDisplayIndex.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDisplayIndex.setBounds(10, 222, 457, 41);
		contentPane.add(btnDisplayIndex);
		
		JLabel lblNewLabel = new JLabel("CHOOSE WHICH COST YOU WOULD LIKE TO CALCULATE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(244, 0, 578, 55);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SELECT OPERATIONS");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(126, 65, 176, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("JOIN OPERATIONS");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1_1.setBounds(820, 63, 156, 31);
		contentPane.add(lblNewLabel_1_1);
		
		JButton btnUsingANonprimary_1 = new JButton("USING A NON-PRIMARY KEY WITH RANGE OPERATOR");
		btnUsingANonprimary_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "DELETE FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql);
					String sql2 = "EXPLAIN PLAN FOR\r\n"
							+ "SELECT * FROM SECTION WHERE \"Year\" >= 2020 AND \"Year\" <= 2022";
					ut.rs = ut.stmt.executeQuery(sql2);
					String sql3 = "SELECT PLAN_ID, OPERATION, OPTIONS, OBJECT_NAME, OBJECT_TYPE, COST, CARDINALITY, BYTES, TIME\r\n"
							+ "FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql3);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});	
		btnUsingANonprimary_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnUsingANonprimary_1.setBounds(10, 282, 457, 41);
		contentPane.add(btnUsingANonprimary_1);
		
		JButton btnUsingANonprimary = new JButton("USING EQUI-JOIN");
		btnUsingANonprimary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "DELETE FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql);
					String sql2 = "EXPLAIN PLAN FOR \r\n"
							+ "SELECT SE.SecId, SE.SecNo, SE.Sem, S.\"SId\", S.FName, S.LName, C.CCode, C.CoName\r\n"
							+ "FROM SECTION SE\r\n"
							+ "JOIN STUDENT_TAKES ST ON SE.SecId = ST.SecId\r\n"
							+ "JOIN STUDENT S ON ST.\"SId\" = S.\"SId\"\r\n"
							+ "JOIN COURSE C ON SE.SecId = C.SecId";
					ut.rs = ut.stmt.executeQuery(sql2);
					String sql3 = "SELECT PLAN_ID, OPERATION, OPTIONS, OBJECT_NAME, OBJECT_TYPE, COST, CARDINALITY, BYTES, TIME\r\n"
							+ "FROM PLAN_TABLE";
					ut.rs = ut.stmt.executeQuery(sql3);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnUsingANonprimary.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnUsingANonprimary.setBounds(800, 102, 176, 41);
		contentPane.add(btnUsingANonprimary);
	}
}
