import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

public class DisplayStudent_TakesMetaDataAndStatistics extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnDisplayColumn;
	private JButton btnDisplayIndex;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DisplayStudent_TakesMetaDataAndStatistics frame = new DisplayStudent_TakesMetaDataAndStatistics();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DisplayStudent_TakesMetaDataAndStatistics() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 748, 494);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 83, 714, 311);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		btnNewButton = new JButton("DISPLAY TABLE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "SELECT NUM_ROWS, AVG_ROW_LEN, AVG_SPACE, BLOCKS, EMPTY_BLOCKS, SAMPLE_SIZE\r\n"
							+ "FROM USER_TABLES WHERE TABLE_NAME = 'STUDENT_TAKES'";
					ut.rs = ut.stmt.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(10, 10, 191, 50);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Go Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_TakesSubMain Student_TakessubmainFrame = new Student_TakesSubMain();
				Student_TakessubmainFrame.setVisible(true);
				setVisible(false);
			}
			
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_1.setBounds(608, 426, 116, 21);
		contentPane.add(btnNewButton_1);
		
		btnDisplayColumn = new JButton("DISPLAY COLUMN");
		btnDisplayColumn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "SELECT COLUMN_NAME, COLUMN_ID, DATA_TYPE, DATA_LENGTH, NULLABLE, DATA_DEFAULT, NUM_NULLS, NUM_DISTINCT, CHAR_LENGTH, DATA_PRECISION\r\n"
							+ "FROM USER_TAB_COLUMNS WHERE TABLE_NAME = 'STUDENT_TAKES'";
					ut.rs = ut.stmt.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			}
		);
		btnDisplayColumn.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDisplayColumn.setBounds(264, 10, 208, 50);
		contentPane.add(btnDisplayColumn);
		
		btnDisplayIndex = new JButton("DISPLAY INDEX");
		btnDisplayIndex.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Utility ut = new Utility();
					String sql = "SELECT INDEX_NAME, NUM_ROWS, UNIQUENESS, STATUS, INDEX_TYPE, JOIN_INDEX\r\n"
							+ "FROM USER_INDEXES WHERE TABLE_NAME = 'STUDENT_TAKES'";
					ut.rs = ut.stmt.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(ut.rs));
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnDisplayIndex.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDisplayIndex.setBounds(533, 10, 191, 50);
		contentPane.add(btnDisplayIndex);
	}

}
